# Independent QA ledger

Builder: https://ampcode.com/threads/T-01a0a0c2-2175-753f-8007-2722dea9c871

Initial candidate: Changes capture `cap_01a0a274adaf71818a97730a24062bca`, downloaded to `/tmp/ember-qa`. This is separate from the builder's live checkout.

Previously verified corrected snapshot: builder's `.amp/qa-build.tar.gz`, extracted to `/tmp/ember-fixed`, SHA-256 `6d406164fa836d70591ba6a28c48d0344d59da4ba80b2efc0ad9403ca598f2d5`.

Previously verified art/polish candidate: archive extracted to `/tmp/ember-complete`, SHA-256 `0d031aca95cae241a28ce3c54f3f6e4434e529432d60283df8e297eb6ce78af4`.

Previously verified card differentiation candidate: archive extracted to `/tmp/ember-card-audit`, SHA-256 `1b86a1af8be1738ba255acf9a173f98ee5e9c487ede00b6bf0249cf204bae5f9`.

Current verified Wayfarer candidate: SHA-256 `290e2b892647d04fbac2e32168f76c5b03cf03005621e3c5f661cbd891bf6c92`, extracted to `/tmp/ember-wayfarer-fixed`.

Gate: PASS for the scoped Wayfarer UI regression. QA-003 is fixed; no corrective implementation is currently required. This is not human readability, balance, performance or Safari certification.

## QA-003

- Severity: MINOR
- Title: Narrow comparison title escapes fixed Wayfarer header
- First detected: 2026-09-15
- Affected system: card layout in camp/read-only improvement comparisons
- Status: FIXED
- Last tested: 2026-09-15, corrected Wayfarer candidate in production-preview Chromium at390×844 and1280×900 DPR2
- Reproduction: Camp → Prepare for tomorrow → Shoulder the burden. Move pointer outside cards and close art preview. Improved title line clips against top frame and spills into art. Actual title height64.78px exceeds40px header; its bottom344.98px exceeds artwork top332.59px. Base title also exceeds its header.
- Regression coverage required: actual long-title base/improved comparisons at390px and desktop; all64 variants measured by title text bounds, not merely header container bounds. Preserve full title/+ and accessible confirmation, art-only preview and selected/busy suppression.
- Evidence: `.amp/in/artifacts/wayfarer-qa-upgrade.webp` (pre-fix screenshot), also uploaded to builder as `.amp/qa-wayfarer-title-overlap.webp`.
- Fix verified: original independent probe changed from26 failing narrow variants to0/64. New actual-render regression independently executed:256 face checks across camp/read-only and narrow/desktop, all passed; physical confirmation changes only Burden and consumes camp at both widths. Title and individual glyph bounds are checked. Corrected narrow camp title309.60→341.99 sits within header289.80→361.80, above artwork361.80.
- Inspected corrected narrow camp/read-only and desktop camp screenshots: full titles/+ fit, rules/footer and confirmation/back controls remain readable. Corrected representative `.amp/in/artifacts/wayfarer-qa-upgrade-fixed.webp`.

## Wayfarer regression evidence

- Original Wayfarer candidate7ac299 passed95 tests/10679 assertions, build/typecheck; game files unchanged from prior card-definition candidate. Corrected290e2b candidate independently passes the same suite/build; only comparison CSS changed in production since7ac299.
- Art-only pointer hover opens preview; title/rules do not. Selection closes all hand previews;59 busy samples with attempted pointer re-entry had0open previews. Normal hover resumes afterward. Twin arrows committed once with expected energy and damage.
- Both draw-pile states open order-hidden inspection. Empty back is decorative and dimmed to opacity0.45. Ten-card narrow hand's last card is fully reachable by scroll controls. Camp confirmation upgrades one copy and consumes the camp.
- Original Wayfarer reduced browser journey lantern completed18stops/victory40HP with engine parity. It required two automation pauses for departing art popovers at shop/camp, so this is assisted evidence, not an uninterrupted run. Original Wayfarer browser error checks were empty.
- Corrected candidate's actual-render script completed and closed its own session. A later error-log request in the separate manual session hung and was stopped, so no additional final error-log claim is made. Layout assertions and screenshots completed beforehand.

## QA-001

- Severity: MAJOR
- Title: Save import accepts stranded map and contradictory terminal state
- First detected: 2026-09-15
- Affected system: save boundary and progression validation
- Status: FIXED
- Last tested: 2026-09-15, final candidate regression tests; corrected snapshot also verified by actual browser import
- Reproduction: Set a new run's row to 5 and location to its boss node while retaining map scene. Import returns valid, but no travel action succeeds. A new map run with zero HP also imports as valid.
- Regression coverage required: stranded map, zero-HP nonterminal, final-act boss reward, legitimate scene and ending round-trips throughout complete journeys.

## QA-002

- Severity: MINOR
- Title: Boss half-health description excludes the implemented boundary
- First detected: 2026-09-15
- Affected system: boss rules text and intent preview
- Status: FIXED
- Last tested: 2026-09-15, final candidate, descriptions and exact-half/just-above tests
- Reproduction: Boss attack bonus activates at HP <= half, but all three descriptions say below half.
- Regression coverage required: exactly half and just above half; preserve existing numeric behavior and correct text.

## Verification evidence

- Initial candidate: `bun test`: 80 pass, 0 fail, 9,054 assertions.
- Initial candidate: `bun run build`: typecheck and production build pass.
- Expanded legal simulation: 100 seeds, 19,655 actions, 95 wins, 5 losses, zero invalid committed save states. Automated win rates do not establish human balance.
- Chromium animated full run: seed lantern, 217 verified UI actions, 18 stops, victory at 40 HP, no application errors or failed resources.
- Corrected snapshot: `bun test`: 85 pass, 0 fail, 10,126 assertions; `bun run build` passes, fixture generation passes.
- Corrected snapshot Chromium full run with mute and reduced motion: seed home, 195 verified UI actions, 18 stops, victory at 51 HP.
- Browser import of stranded save rejects it, preserves the existing save byte-for-byte, and does not offer Replace save.
- Duplicate target clicks commit one Twin arrows card: energy 3 to 2, wolf block 10 to 2, HP remains 40, one discard instance.
- Ten-card hand offers horizontal scrolling controls; core controls remain available at 1280×720. Representative screenshot inspected.
- Defeat fixture ends at 0 HP with loss scene and unlocked ending controls. No browser errors.
- Final candidate: `bun test`: 86 pass, 0 fail, 10,387 assertions; typecheck/build/fixture generation pass. Rules engine unchanged from previously verified candidate.
- Final candidate animated legal Chromium run: lantern, 217 matched actions, 18 stops, victory at 40 HP. Browser errors empty; no resource status >=400.
- All 16 new sheets decode at 1536×1024 in Chromium. Rendering tests verify 64 distinct image/crop combinations. Inspected actual combat art and desktop/narrow upgrade previews, with no bleed, overlap, or hidden confirmation control.
- At 390×844, no page horizontal overflow; upgrade confirmation changed only Ancient flame and consumed the camp action. Desktop comparison renders distinct 18-damage and 24-damage cards.
- Live 16ms DOM sampling: Twin arrows shows HP 40→36→32 and projectile nodes, duplicate target clicks commit one card. Ancient flame then shows 32→14 HP, spell/Dread effects, zero remaining energy and Dread 6.
- Reload during enemy-phase presentation preserves committed save bytes. Reduced-motion action leaves zero active animations and effect elements.
- Independently captured 7 seconds of actual Web Audio output: nonzero music, continuous on listening review without clicks/restart stutters. Separate muted capture after settling: peak and RMS -inf. Listening copy amplified 20 dB for inspection only.
- Builder-supplied combat recording reviewed as supporting evidence, not counted as an independent execution. Ordinary independent browser video capture truncated and was not used as proof.
- Limitations: Chromium/Linux only; no macOS/Safari testing or human balance assessment. Short independent audio sample does not establish every regional arrangement or long-term scheduling performance. No stable-60-FPS claim.
- Prior builder results are historical evidence, not independent verification of this candidate.

## Card differentiation regression, 2026-09-15

- Verified candidate archive hash and production diff: only Hidden trail and Shoulder the burden definitions changed; engine and other production files are identical to the prior approved snapshot.
- Independently ran builder suite: 94 tests, 10,481 assertions, zero failures; typecheck, production build and fixture generation pass. Suite includes complete legal journeys and prior QA-001/002 coverage.
- Independent additional checks: 10 tests, 110 assertions, zero failures. Includes Trail empty piles, two-copy discard draw/exhaust termination, ten-card hand replacement, zero-Dread clamp, no Silver thread Block, illegal replay rejection, Burden normal/Quiet bell thresholds and Dread cap at both tiers, and importing an old discarded Trail then playing it under the new definition.
- Independent unordered effect-package screening across all 32 cards and both tiers reproduced the three old same-cost/same-tier collisions and found zero in the new catalog. It is a duplicate screen, not a proof of strategic distinctness or balance.
- Chromium muted/reduced isolated fixture: upgraded Burden changes energy 0→3, Dread 1→4, exhausts without prematurely firing thresholds. Upgraded Trail then changes Dread 4→2, retains energy3, draws one card, grants zero Block and exhausts. Browser error log empty.
- Accessibility labels and inspected screenshot match both revised upgraded definitions, with no clipped rules. Screenshot: `.amp/in/artifacts/card-audit-upgraded.webp`.
- No corrective implementation required. No new broad balance simulation, human test or Safari verification performed.
