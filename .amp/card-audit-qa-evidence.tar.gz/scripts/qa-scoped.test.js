import { test, expect } from 'bun:test';
import { CARDS } from '../src/game/content.ts';
import { newRun, makeCard, makeEnemy, startCombat, resolve, thresholds } from '../src/game/engine.ts';
import { parseSave, defaultSettings } from '../src/game/storage.ts';
import { CARDS as OLD } from '/tmp/ember-complete/src/game/content.ts';
import { resolve as oldResolve } from '/tmp/ember-complete/src/game/engine.ts';

function fixture(ids, upgraded = false) {
  const run = newRun('qa-card-boundaries');
  const node = run.route.find(n => n.row === 0);
  run.row = 0; run.location = node.id; run.visited = [node.id];
  run.deck = ids.map(id => ({...makeCard(run, id), upgraded}));
  startCombat(run, 'battle');
  Object.assign(run.scene, {hand: [...run.deck], draw: [], discard: [], exhaust: [], energy: 0, dread: 4,
    enemies: [makeEnemy(run, 'wolf')], reaction: 'fury'});
  return run;
}
function play(run, uid = run.scene.hand[0].uid) {
  const result = resolve(run, {type:'play',uid,target:null});
  expect(result.error).toBeNull();
  expect(parseSave(JSON.stringify(result.run)).kind).toBe('valid');
  return result.run;
}
test('independent unordered effect screening finds three old collisions and none new', () => {
  function collisions(cards) {
    const found=[];
    for(const up of [false,true]) for(let i=0;i<cards.length;i++) for(let j=i+1;j<cards.length;j++) {
      const key=c=>JSON.stringify([c.cost,c.effects.map(e=>[e.kind,e.amount+(up?e.upgrade:0)]).sort()]);
      if(key(cards[i])===key(cards[j]))found.push([up,cards[i].id,cards[j].id]);
    }
    return found;
  }
  expect(collisions(OLD)).toEqual([[false,'trail','courage'],[true,'trail','courage'],[true,'spark','sacrifice']]);
  expect(collisions(CARDS)).toEqual([]);
});
for(const upgraded of [false,true]) {
  test(`Trail empty piles, zero-Dread clamp and no Thread Block, upgraded=${upgraded}`,()=>{
    const run=fixture(['trail'],upgraded); run.relics=['thread']; run.scene.dread=0;
    const next=play(run);
    expect([next.scene.hand.length,next.scene.draw.length,next.scene.discard.length,next.scene.exhaust.length]).toEqual([0,0,0,1]);
    expect([next.scene.block,next.scene.dread,next.scene.energy]).toEqual([0,0,0]);
    const repeated=resolve(next,{type:'play',uid:run.deck[0].uid,target:null});
    expect(repeated.error).not.toBeNull();expect(repeated.run).toEqual(next);
  });
  test(`two Trails draw through discard without recycling exhausted instances, upgraded=${upgraded}`,()=>{
    const run=fixture(['trail','trail'],upgraded);
    run.scene.hand=[run.deck[0]];run.scene.discard=[run.deck[1]];run.scene.draw=[];
    const next=play(run);
    expect(next.scene.hand[0].uid).toBe(run.deck[1].uid);
    const last=play(next,run.deck[1].uid);
    expect(last.scene.hand).toEqual([]);
    expect(last.scene.exhaust.map(c=>c.uid)).toEqual([run.deck[0].uid,run.deck[1].uid]);
  });
  test(`Trail replaces its own slot in a ten-card hand, upgraded=${upgraded}`,()=>{
    const run=fixture(['trail',...Array(10).fill('guard')],upgraded);
    run.scene.hand=run.deck.slice(0,10);run.scene.draw=[run.deck[10]];
    const next=play(run);
    expect(next.scene.hand.length).toBe(10);expect(next.scene.hand.some(c=>c.uid===run.deck[10].uid)).toBe(true);
    expect(next.scene.dread).toBe(upgraded?2:3);
  });
  test(`Burden boundary, quiet bell and clamp preserve deferred thresholds, upgraded=${upgraded}`,()=>{
    for(const dread of [1,8]) for(const bell of [false,true]) {
      const run=fixture(['sacrifice'],upgraded);run.scene.dread=dread;if(bell)run.relics=['charm'];
      const next=play(run);
      expect(next.scene.energy).toBe(upgraded?3:2);expect(next.scene.dread).toBe(dread===1?4:10);
      expect(next.scene.fired).toEqual([]);
      expect(thresholds(next,next.scene).filter(t=>t.pending).length).toBe(dread===8?2:bell?0:1);
      const end=resolve(next,{type:'end'});
      expect(end.error).toBeNull();expect(end.run.scene.fired).toEqual(dread===8?(bell?[5,9]:[4,8]):bell?[]:[4]);
    }
  });
}
test('old discarded Trail remains loadable, then follows new Exhaust definition on next play',()=>{
  const run=fixture(['trail']);
  const old=oldResolve(run,{type:'play',uid:run.deck[0].uid,target:null}).run;
  expect(old.scene.discard.length).toBe(1);expect(old.scene.block).toBe(3);
  const saved=parseSave(JSON.stringify(old));expect(saved.kind).toBe('valid');
  const next=resolve(saved.run,{type:'end'}).run;
  expect(next.scene.hand[0].def).toBe('trail');
  const played=play(next);expect(played.scene.exhaust.length).toBe(1);expect(played.scene.block).toBe(0);
});

const browser=fixture(['trail','sacrifice','needle','guard'],true);
browser.scene.hand=browser.deck.slice(0,2);browser.scene.draw=browser.deck.slice(2);browser.scene.dread=1;
await Bun.write('/tmp/card-audit-browser.json',JSON.stringify(browser));
await Bun.write('/tmp/card-audit-settings.json',JSON.stringify({...defaultSettings,muted:true,reduced:true,tutorial:false}));
